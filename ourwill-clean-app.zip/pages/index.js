
import RegisterUser from '../src/RegisterUser';

export default function Home() {
  return (
    <div>
      <RegisterUser />
    </div>
  );
}
